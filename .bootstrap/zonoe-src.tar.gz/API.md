# REST API v1

统一前缀：`/api/v1`。下载入口保持 `/download/{appId}`。

## 返回格式

成功：

```json
{"data": {}}
```

分页：

```json
{"data": [], "meta": {"page":1,"pageSize":20,"total":0,"totalPages":1}}
```

失败：

```json
{"error":{"code":"VALIDATION_ERROR","message":"参数校验失败","details":[]}}
```

主要错误码：`VALIDATION_ERROR`、`UNAUTHORIZED`、`CSRF_INVALID`、`NOT_FOUND`、`CONFLICT`、`REFERENCE_IN_USE`、`APP_NOT_FOUND`、`VERSION_NOT_FOUND`、`NO_AVAILABLE_SOURCE`、`FILE_TOO_LARGE`、`INTERNAL_ERROR`。

## Public

### `GET /api/v1/home`
返回推荐、最新、热门、分类、公告。

### `GET /api/v1/apps`
参数：

- `q`: 名称/Bundle ID/开发者/简介搜索
- `category`: category slug
- `tag`: tag slug
- `sort`: `latest|popular|name`
- `featured`: `true|false`
- `hot`: `true|false`
- `page`: >= 1
- `pageSize`: 1..100

### `GET /api/v1/search`
与 `/apps` 相同，便于前端语义化调用。

### `GET /api/v1/apps/{idOrSlug}`
返回 App、分类、标签、截图、全部已发布版本。

### `GET /api/v1/apps/{idOrSlug}/versions`
返回已发布历史版本。

### `GET /api/v1/categories`
启用分类。

### `GET /api/v1/tags`
全部标签。

### `GET /download/{appId}`
可选 query：`versionId`。不指定则选择最新已发布版本。成功 `302 Location: <resolved-url>`；没有可用源返回 503。

## Admin Authentication

### `POST /api/v1/admin/auth/login`

```json
{"email":"admin@example.com","password":"..."}
```

成功写入 HttpOnly `zonoe_admin` JWT Cookie 和可读 `zonoe_csrf` Cookie。

### `GET /api/v1/admin/auth/me`
要求 Admin Cookie。

### `POST /api/v1/admin/auth/logout`
要求 Admin Cookie + `X-CSRF-Token`。

所有 Admin 修改请求必须：

```http
Cookie: zonoe_admin=...; zonoe_csrf=...
X-CSRF-Token: <zonoe_csrf value>
```

## Admin App

- `GET /api/v1/admin/apps?q=&status=&page=&pageSize=`
- `GET /api/v1/admin/apps/{id}`
- `POST /api/v1/admin/apps`
- `PUT /api/v1/admin/apps/{id}`
- `DELETE /api/v1/admin/apps/{id}`：软删除 App
- `POST /api/v1/admin/apps/{id}/versions`
- `PUT /api/v1/admin/versions/{id}`
- `DELETE /api/v1/admin/versions/{id}`

App body：

```json
{
  "name":"Example",
  "slug":"example",
  "bundleId":"com.example.app",
  "iconUrl":"https://.../icon.png",
  "shortDesc":"简介",
  "description":"完整介绍",
  "developer":"Developer",
  "status":"PUBLISHED",
  "featured":false,
  "hot":false,
  "sortOrder":0,
  "categoryId":null,
  "tagIds":[],
  "screenshots":[]
}
```

Version body：

```json
{
  "version":"1.2.0",
  "build":"120",
  "sizeBytes":123456789,
  "minIos":"15.0",
  "changelog":"...",
  "status":"PUBLISHED",
  "publishedAt":"2026-09-12T00:00:00.000Z",
  "sources":[
    {"sourceId":"uuid","target":"IPA/App_1.2.0.ipa","priority":10,"enabled":true}
  ]
}
```

## Admin Categories/Tags

- `GET|POST /api/v1/admin/categories`
- `PUT|DELETE /api/v1/admin/categories/{id}`
- `GET|POST /api/v1/admin/tags`
- `DELETE /api/v1/admin/tags/{id}`

## Admin Download Sources

- `GET|POST /api/v1/admin/download-sources`
- `PUT|DELETE /api/v1/admin/download-sources/{id}`

Source body：

```json
{
  "name":"天翼 OpenList",
  "type":"OPENLIST",
  "enabled":true,
  "priority":20,
  "config":{"baseUrl":"https://pan.example.com"},
  "secretConfig":{"token":"optional-secret"}
}
```

`secretConfig` 加密保存；GET 只返回 `hasSecret`。

## Admin Upload/Statistics/Settings

- `POST /api/v1/admin/upload`: `multipart/form-data`, field `file`, `.ipa`
- `GET /api/v1/admin/statistics`
- `GET /api/v1/admin/settings`
- `PUT /api/v1/admin/settings/{key}` body `{"value": ...}`
