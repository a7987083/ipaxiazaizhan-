# ZONOE IPA 下载站

生产可用的 IPA 下载站，面向 iPhone/iPad 与桌面浏览器。前台采用 Mobile First 的 App Store 风格布局，后台同样支持手机管理。IPA 文件与站点计算层解耦，下载统一经过 Download Service 记录统计后 302 到实际存储。

## 技术栈

- Frontend: React 19 + Vite + React Router，响应式单页应用/PWA Manifest
- Backend: Node.js 22 + TypeScript + Fastify
- Database: PostgreSQL 16 + Prisma
- Cache: Redis 7 可选；未配置时使用进程内 30 秒 TTL Cache
- Web Server: Nginx
- Deployment: Docker Compose
- Storage: Adapter 模式，已实现 LOCAL / HTTP / OPENLIST / CLOUD / CDN / OTHER

## 下载链路

```text
Browser -> GET /download/{appId}[?versionId=...]
        -> Download Service
        -> 选择启用且优先级最高的 VersionDownloadSource
        -> Storage Adapter 解析目标 URL
        -> 写入 downloads + 原子增加 App/Version 下载计数
        -> HTTP 302
        -> OpenList / 天翼云盘 / CDN / HTTP / 本地 Nginx
```

IPA 大文件不会经过 Node.js 应用进程。LOCAL 类型也由 Nginx `/files/` 直接发送文件。

## 开发启动

```bash
cp .env.example .env
# 修改 DATABASE_URL、JWT_SECRET、SOURCE_CONFIG_KEY、IP_HASH_SALT、ADMIN_EMAIL、ADMIN_PASSWORD
npm install
npm run db:generate -w backend
npm run db:migrate -w backend
npm run db:seed -w backend
npm run dev:backend
npm run dev:frontend
```

开发环境前端默认 `http://localhost:5173`，API 默认 `http://localhost:3000`，Vite 自动代理 `/api` 与 `/download`。

## Docker 部署

```bash
cp .env.example .env
mkdir -p data/uploads data/logs/nginx data/letsencrypt data/certbot
# 修改 .env

docker compose up -d --build
docker compose exec api npm run db:seed
BASE_URL=http://127.0.0.1 ./scripts/smoke.sh
```

HTTPS、备份和升级见 [DEPLOY.md](DEPLOY.md)。

## 后台

访问 `/admin/login`。首次管理员由 `.env` 的 `ADMIN_EMAIL` / `ADMIN_PASSWORD` 配合 `npm run db:seed` 创建或重置密码。

后台支持：

- App CRUD / 上架 / 下架 / 推荐 / 热门 / 排序
- 多版本管理
- 每个版本绑定多个下载源并配置优先级
- 本地 IPA 上传
- 分类 / 标签
- 下载源管理
- 下载统计
- 首页公告
- 手机端管理

## OpenList

推荐创建 `OPENLIST` 下载源：

```json
{
  "baseUrl": "https://pan.example.com"
}
```

版本目标填写 OpenList 内相对路径，例如：

```text
IPA/AppName/AppName_1.2.0.ipa
```

默认解析为：

```text
https://pan.example.com/d/IPA/AppName/AppName_1.2.0.ipa
```

如果你的 OpenList 路径格式不同，可使用：

```json
{
  "template": "https://pan.example.com/custom/{path}"
}
```

## 文档

- [ARCHITECTURE.md](ARCHITECTURE.md)
- [DATABASE.md](DATABASE.md)
- [API.md](API.md)
- [DEPLOY.md](DEPLOY.md)
- [CHANGELOG.md](CHANGELOG.md)
- [HANDOFF.md](HANDOFF.md)
- [PROJECT_STATE.json](PROJECT_STATE.json)
