# Changelog

## 1.0.0-dev1 - 2026-09-12

- 建立 ZONOE IPA 下载站完整前后端工程。
- React/Vite Mobile First 前台，实现首页、App 列表、分类/搜索、详情、历史版本与下载入口。
- 实现手机/PC 自适应后台：登录、App CRUD、Version CRUD、分类、标签、下载源、上传、统计、公告。
- Fastify REST API v1，PostgreSQL/Prisma 数据层。
- Download Service + Storage Adapter；支持 LOCAL/HTTP/OPENLIST/CLOUD/CDN/OTHER 与多源优先级。
- 下载 302、统计写入、失败记录、Rate Limit。
- Admin JWT HttpOnly Cookie + CSRF + Argon2id。
- IPA 上传 ZIP Magic 检查、随机文件名与 Nginx 直接下载。
- Redis 可选公共 API Cache。
- Docker Compose、Nginx、HTTPS 模板、Migration、Backup、Smoke Test、GitHub Actions CI。
